//
//  CheckedCellModel.swift
//  LiveView
//
//  Created by Liz Chaddock on 6/29/17.
//  Copyright © 2017 Liz Chaddock. All rights reserved.
//

import Foundation

class CheckedCellModel : NSObject {
    var title : String
    var checked: Bool
    var subtitle : String
    
    init(title: String, checked: Bool, subtitle: String) {
        self.title = title
        self.checked = checked
        self.subtitle = subtitle
    }
}
