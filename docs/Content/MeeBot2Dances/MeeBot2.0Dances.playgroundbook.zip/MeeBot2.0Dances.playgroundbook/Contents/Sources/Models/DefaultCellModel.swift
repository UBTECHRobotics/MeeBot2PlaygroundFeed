//
//  DefaultCellModel.swift
//  LiveView
//
//  Created by Liz Chaddock on 6/29/17.
//  Copyright © 2017 Liz Chaddock. All rights reserved.
//

import Foundation

class DefaultCellModel : NSObject {
    var title : String
    
    init(title: String) {
        self.title = title
    }
}
