//
//  SceneController+Animation.swift
//  PlaygroundScene
//
//  Created by newman on 17/3/15.
//  Copyright © 2017年 UBTech Inc. All rights reserved.
//

import Foundation
import UIKit
import SceneKit

func calibrate_step_duration(_ duration:Double) -> Double {
    return max(0.25, min(duration, 5))
}

extension SceneController{
    
    func loadAnimations() {
        //load servo angles
        if let p = Bundle.main.path(forResource: "Angles/servo_angles", ofType: "plist"), let nd = NSDictionary(contentsOfFile: p) as? [String:[[UInt8]]] {
            nd.forEach{
                //FIXME: - left and right arms move the opposite direction
                let fixedMoves: [[UInt8]] = $1.map { originalMoves in
                    return originalMoves.enumerated().map { (index, move) -> UInt8 in
                        let m: UInt8 = (index == 1 || index == 4) ? UInt8( Int(move) +  2 * (120 - Int(move))) : move
                        return m
                    }
                }
                if let a = Action(rawValue:$0) {
                    servoAngles[a] = fixedMoves
                }
            }
        }
        //load animation
        Bundle.main.paths(forResourcesOfType: "plist", inDirectory: "Actions").forEach{
            if let dict  = NSArray(contentsOfFile: $0) as? [[String:[Double]]], let last = $0.components(separatedBy: "/").last, let name = last.components(separatedBy: ".").first, let a = Action(rawValue:name){
                animations[a] = dict
            }
        }
        //load correct animations
        let decoder = JSONDecoder()
        jimuAnimations = Bundle.main.paths(forResourcesOfType: "json", inDirectory: "Animations").compactMap {
            guard
                let jsonData = FileManager.default.contents(atPath: $0),
                var animation = try? decoder.decode(AnimationsRoot.self, from: jsonData)
                else { return nil }
            animation.name = String(String($0.split(separator: "/").last ?? "").split(separator: ".").first ?? "")
            return animation
        }
    }
    
    func runCommonAnimation(_ action: Action, beats: Double? = nil) {
        let animation = jimuAnimations.filter { $0.name == action.rawValue }.first
        var speedMultiplier: Double = calibrate_step_duration((beats ?? 1.0))
        guard
            let timeDurations = animation?.timeDurations(),
            let angles = animation?.angles()
            else {
            liveLog("runCommonAnimation ERROR : missing command: \(action)")
            return
        }
        // NOTE: - check for maximum animation duration
        let maxDuration = timeDurations.max() ?? 1.0
        speedMultiplier = maxDuration > 1 ? 5.0 : speedMultiplier
        if let animation = extractAnimation(for: action, speedMultiplier: speedMultiplier) {
//            for animationKey in scnView.scene?.rootNode.animationKeys ?? [] {
//                scnView.scene?.rootNode.removeAnimation(forKey: animationKey)
//            }
            liveLog("previous animations \(scnView.scene?.rootNode.animationKeys ?? [])")
            if #available(iOS 11.0, *) {
                scnView.scene?.rootNode.removeAnimation(forKey: "animation", blendOutDuration: 0.2)
            } else {
                scnView.scene?.rootNode.removeAllAnimations()
            }
            scnView.scene?.rootNode.addAnimation(animation, forKey: "animation")
            liveLog("current animations \(scnView.scene?.rootNode.animationKeys ?? [])")
        } else if action == .standBy {
           reset3DModel()
        }
        var index = 1
        var delay: Double = 0
        var animationIndex = 1
        while index < angles.count {
            let timer = Timer.scheduledTimer(withTimeInterval: delay, repeats: false) {[weak self] _ in
                MeeBot.shared.setServos(angles[animationIndex], duration: UInt((timeDurations[animationIndex] * 1000) * speedMultiplier))
                animationIndex += 1
                if animationIndex == angles.count {
                    _ = Timer.scheduledTimer(withTimeInterval: timeDurations[animationIndex-1], repeats: false) {[weak self] _ in
                        self?.onAnimationFinish()
                    }
                }
                self?.animationTimeStamp = CFAbsoluteTimeGetCurrent()
            }
            animationTimers.append(timer)
            delay += timeDurations[index] * speedMultiplier
            index += 1
        }
    }
    
    /// Set 3D model node rotations to the initial state (standBy Action)
    private func reset3DModel() {
//        scnView.scene?.rootNode.removeAllAnimations()// .removeAnimation(forKey: "animation", fadeOutDuration: 1)
        if #available(iOS 11.0, *) {
            scnView.scene?.rootNode.removeAnimation(forKey: "animation", blendOutDuration: 1.0)
        } else {
            scnView.scene?.rootNode.removeAllAnimations()
        }
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 1.0
        for index in 1...6 {
            scnView.scene?.rootNode.childNode(withName: "ServoID\(index)", recursively: true)?.removeAllActions()
            scnView.scene?.rootNode.childNode(withName: "ServoID\(index)", recursively: true)?.eulerAngles = SCNVector3Zero
        }
        scnView.scene?.rootNode.childNode(withName: "Neck", recursively: true)?.removeAllActions()
        scnView.scene?.rootNode.childNode(withName: "Neck", recursively: true)?.eulerAngles = SCNVector3Zero
        SCNTransaction.commit()
    }
    
    private func extractAnimation(for action: Action, speedMultiplier: Double) -> CAAnimation? {
        guard let sceneURLs = Bundle.main.urls(forResourcesWithExtension: "scn", subdirectory: "Animations") else { return nil }
        guard let sceneURL: URL = (sceneURLs.filter { $0.relativePath.contains(action.rawValue) }.first) else { return nil }
        let t = SCNReferenceNode(url: sceneURL)
        t?.load()
        guard let animation = t?.allAnimations.first else { return nil }
        animation.speed = animation.speed / Float(speedMultiplier)
        animation.repeatCount = 0
        return animation
    }
    
    func runMoveBodyAnimation(_ angles: [Int8?], beats: Double? = nil) {
        let beats_per_step = beats ?? 0 > 0 ? beats! : 1.0
        let duration_per_step = calibrate_step_duration(beats_per_step * 60 / Double(bpm) * timeScale)
//        duration_per_step = 10
        
        liveLog("duration_per_step \(duration_per_step)")
        let anglesForRobot: [UInt8?] = angles.enumerated().map { (index, angle) in
            guard let angle = angle else {
                return nil
            }
            // FIXME: - swap left and right arm angles
            // 1 : right arm
            // 4 : left arm
            return UInt8(120 + ( (index == 4 || index == 1) ? -Int(angle) : Int(angle) ) )
        }
        MeeBot.shared.setServos(anglesForRobot, duration:UInt(duration_per_step * 1000))

        var acts = [String: SCNAction]()
        for (i, e) in angles.enumerated() {
            if let ee = e {
                let vector = i == 0 || i == 3 ? SCNVector3(0, 1, 0) : SCNVector3(0, 0, 1)
                let rotate = SCNAction.rotateTo(x: CGFloat(vector.x) * CGFloat(ee) * CGFloat(Double.pi / 180),
                                                 y: CGFloat(vector.y) * CGFloat(ee) * CGFloat(Double.pi / 180),
                                                 z: CGFloat(vector.z) * CGFloat(ee) * CGFloat(Double.pi / 180),
                                                 duration: duration_per_step, usesShortestUnitArc: true)
                acts["ServoID\(i+1)"] = rotate
                if i == 4 {
                    acts["Neck"] = SCNAction.rotateTo(x: 0, y: CGFloat(ee) * CGFloat(Double.pi / 180) / 2, z: 0,
                    duration: duration_per_step, usesShortestUnitArc: true)
                }
            }
        }
        //腿没动就是没联动，可以reset以避免3D运行混乱
        if angles[0] == nil && angles[3] == nil {
            if let vs = animations[.standBy]?.first {
                vs.forEach{
                    let move = SCNAction.move(to: SCNVector3($1[0], $1[1], $1[2]), duration: duration_per_step)
                    let rotate = SCNAction.rotateTo(x: CGFloat($1[3] * Double.pi / 180) , y: CGFloat($1[4] * Double.pi / 180), z: CGFloat($1[5] * Double.pi / 180), duration: duration_per_step, usesShortestUnitArc: true)
                    if let r = acts[$0] {
                        acts[$0] = SCNAction.group([move, r])
                    }else{
                        acts[$0] = SCNAction.group([move, rotate])
                    }
                }
            }
        }
        acts.forEach{
            if let node = self.scnView.scene?.rootNode.childNode(withName: $0, recursively: true) {
                node.removeAllActions()
                node.runAction($1)
            }
        }
        let time = CFAbsoluteTimeGetCurrent()
        liveLog("duration moveBody \(time - animationTimeStamp)")
        animationTimeStamp = time
        stopTimers()
        animationTimers.append(Timer.scheduledTimer(withTimeInterval: duration_per_step, repeats: false) {[weak self] _ in
            self?.onAnimationFinish()
        })
        animationTimers.first?.tolerance = 0
    }
}
