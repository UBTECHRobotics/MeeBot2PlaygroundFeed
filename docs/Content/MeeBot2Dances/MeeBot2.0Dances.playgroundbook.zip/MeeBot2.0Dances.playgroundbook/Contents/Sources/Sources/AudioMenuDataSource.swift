//
//  AudioMenuDataSource.swift
//  LiveView
//
//  Created by Liz Chaddock on 6/20/17.
//  Copyright © 2017 Liz Chaddock. All rights reserved.
//

import Foundation
import UIKit
import MediaPlayer
#if APP
import DTTableViewManager
#endif

class AudioMenuDataSource : NSObject, DTTableViewManageable {
    
    // MARK: Properties
    var playMusicEnabled: Bool
    var dataArray: [String]
    var myOwnSongHasBPM: Bool = false
    internal var tableView : UITableView!
    weak var actionHandler : AudioMenuActionHandler?
    var lastIndexPath: IndexPath?

    init(with songArray: [String], actionHandler: AudioMenuActionHandler, tableView: UITableView) {
        self.dataArray = songArray
        self.actionHandler = actionHandler
        self.playMusicEnabled = Persisted.isBackgroundAudioEnabled
        self.tableView = tableView
        super.init()
        self.setupManager()
    }
    
    func setupManager() {
        manager.startManaging(withDelegate:self)
        manager.configuration.sectionHeaderStyle = SupplementarySectionStyle.view
        manager.configuration.sectionFooterStyle = SupplementarySectionStyle.view
        
        manager.register(SwitchCell.self)
        manager.register(CheckedCell.self)
        manager.register(DefaultCell.self)
        manager.memoryStorage.addItem(SwitchCellModel.init(text: NSLocalizedString("Play Music", comment: "cell in the music selection popover"), isOn: playMusicEnabled, selector: #selector(switchControlAction(_:)), target: self), toSection: 0)
        
        for i in 0..<dataArray.count {
            manager.memoryStorage.addItem(CheckedCellModel.init(title: dataArray[i], checked: (i == lastIndexPath?.row && (lastIndexPath != nil)), subtitle: subtitle(from: i)), toSection: 1)
        }
        
        if Persisted.isLastLesson {
            //add 3rd section
            manager.memoryStorage.addItem(DefaultCellModel.init(title: NSLocalizedString("Choose your own song...", comment: "cell in the music selection popover")), toSection: 2)
        }
        
        manager.didSelect(CheckedCell.self) { cell,model,indexPath in
            self.actionHandler?.handleCheckedCellSelection(model: model, index: indexPath.row)
            self.tableView.deselectRow(at: indexPath, animated: true)
        }
        
        manager.didSelect(DefaultCell.self) { cell,model,indexPath in
            self.actionHandler?.handleAddMusicCellSelection(model: model, index: indexPath.row)
            self.tableView.deselectRow(at: indexPath, animated: true)
        }
        
        manager.memoryStorage.setSectionHeaderModels(["", "", ""])
        
        var footerModels = ["", ""]
        
        if Persisted.isLastLesson {
            footerModels.append("")
        }
        
        manager.memoryStorage.setSectionFooterModels(footerModels)
    }
    
    // MARK: - Internal Methods
    func setTableViewCellDefaultSelected() {
        let index: Int =  Persisted.backgroudAudioSelectedIndex
        
        assert(index < dataArray.count, "index for default selection exceeded number of songs")
        Persisted.backgroudAudioSelectedIndex = (index < dataArray.count) ? index : 0
        
        setTableViewCellSelected(index: Persisted.backgroudAudioSelectedIndex)
    }
    
    // selected cell
    func setTableViewCellSelected(index: Int) {
        let selectedIndexPath = IndexPath(row: Int(index), section: 1)
        
        var indexPaths = [IndexPath]()
        if let oldIndexPath = lastIndexPath {
            indexPaths.append(oldIndexPath)
        }
        lastIndexPath = selectedIndexPath
        indexPaths.append(lastIndexPath!)
        updateMemoryForSongs(indexPaths: indexPaths)
    }
    
    func updateSwitchCellModel(enabled: Bool) {
        manager.memoryStorage.updateWithoutAnimations {
            do {
                if let item = manager.memoryStorage.item(at: IndexPath(row:0, section:0)) as? SwitchCellModel {
                    try manager.memoryStorage.replaceItem(item, with: SwitchCellModel.init(text: NSLocalizedString("Play Music", comment: "cell in the music selection popover"), isOn: playMusicEnabled, selector: #selector(switchControlAction(_:)), target: self))
                }
            } catch {
                Logger.debug("caught error: \(error) updating memory")
            }
        }
        tableView.reloadData()
    }
    
    func updateWith(mediaItem: MPMediaItem) {
        guard let musicName = mediaItem.title else {
            return
        }
        
        // Get current music BPM
        var bmpValue = mediaItem.beatsPerMinute
        if bmpValue == 0 {
            bmpValue = 100
            self.myOwnSongHasBPM = false
        } else {
            self.myOwnSongHasBPM = true
        }
        
        // Persisted choosed music and BPM
        Persisted.musicNameFromLib = musicName
        Persisted.musicBPMFromLib = UInt(bmpValue)
        
         if dataArray.count > buildInMusicCount {
            manager.memoryStorage.removeItems(at: [IndexPath.init(row: dataArray.count - 1, section: 1)])
            dataArray.removeLast()
        }
 
            dataArray.append(musicName)
            manager.memoryStorage.addItem(CheckedCellModel.init(title: musicName, checked: false, subtitle: subtitle(from: manager.memoryStorage.totalNumberOfItems - 1)), toSection: 1)
    }
    
    func updateMemoryForSongs(indexPaths: [IndexPath]) {
        for i in indexPaths {
            manager.memoryStorage.updateWithoutAnimations {
                // Add multiple rows, or another batch of edits
                do {
                    if let item = manager.memoryStorage.item(at: i) as? CheckedCellModel {
                        try manager.memoryStorage.replaceItem(item, with: CheckedCellModel.init(title: dataArray[i.row], checked: (i.row == (lastIndexPath?.row)! && (lastIndexPath != nil)), subtitle: subtitle(from: i.row)))
                    }
                } catch {
                    Logger.debug("caught error: \(error) updating memory")
                }
            }
            tableView.reloadData()
        }
    }
    
    //actions
    @objc func switchControlAction(_ switchContrl: UISwitch) {
        if switchContrl.isOn {
            self.setTableViewCellDefaultSelected()
        }
        
        playMusicEnabled = switchContrl.isOn
        self.actionHandler?.enableAudioMenuSelection(switchContrl.isOn)
    }
    
    func subtitle(from row: Int) -> String {
        var currentBPM = UInt(0)
        switch row {
        case 0:
            currentBPM = 60
        case 1:
            currentBPM = 120
        case 2:
            if myOwnSongHasBPM {
                currentBPM = Persisted.musicBPMFromLib
            }
            else {
                currentBPM = 0
            }
        default:
            break
        }
        var subtitleText : String
        if currentBPM > 0 {
            subtitleText = String(format: NSLocalizedString("%d BPM", comment: "subtitle for songs in the music selection menu, indicating BPM of that song"), currentBPM)
        }
        else {
            subtitleText = NSLocalizedString("Input BPM", comment: "subtitle for songs in the music selection menu, indicating we cannot find BPM of song automatically.")
        }
        return subtitleText
    }

}
