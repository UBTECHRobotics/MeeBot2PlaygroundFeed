//
//  MeeBot 2.0.swift
//  BLE
//
//  Created by NewMan on 2017/2/7.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation

public class MeeBot:Robot{
    private static let _shard = MeeBot()
    public class var shared:MeeBot { return _shard }
}
