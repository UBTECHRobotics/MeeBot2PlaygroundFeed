//
//  Logger.swift
//
//  Created by Evan Xie on 2019/3/29.
//

import Foundation

public final class Logger {
    
    public class func debug<T>(_ message: T, file: String = #file, method: String = #function) {
        #if DEBUG
        print("[Debug] [\((file as NSString).lastPathComponent): \(method)] \(message)")
        #endif
    }
    
    public class func error<T>(_ message: T, file: String = #file, method: String = #function) {
        #if DEBUG
        print("[Error] [\((file as NSString).lastPathComponent): \(method)] \(message)")
        #endif
    }
    
    public class func info<T>(_ message: T, file: String = #file, method: String = #function) {
        #if DEBUG
        print("[Info] [\((file as NSString).lastPathComponent): \(method)] \(message)")
        #endif
    }
    
    public class func warning<T>(_ message: T, file: String = #file, method: String = #function) {
        #if DEBUG
        print("[Warning] [\((file as NSString).lastPathComponent): \(method)] \(message)")
        #endif
    }
    
    public class func tag<T>(_ tag: String, message: T, file: String = #file, method: String = #function) {
        #if DEBUG
        print("[\(tag)] [\((file as NSString).lastPathComponent): \(method)] \(message)")
        #endif
    }
}
