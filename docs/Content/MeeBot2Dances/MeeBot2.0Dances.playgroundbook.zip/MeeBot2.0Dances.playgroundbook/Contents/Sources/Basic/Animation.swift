//
//  Animation.swift
//  Book_Sources
//
//  Created by iCat Developer on 30/12/2019.
//

import Foundation

public struct Animation: Codable {
    let rotas: String?
    let sportTime: String?
}

public struct AnimationRoot: Codable {
    let Root: [Animation]
}

public struct AnimationsRoot: Codable {
    let Roots: AnimationRoot
    var name: String?
}

public extension AnimationsRoot {
    func angles() -> [[UInt8?]] {
        return Roots.Root.map { ($0.rotas.map { $0.split(separator: ";").map {
            UInt8($0.split(separator: "$").last ?? "") } } ?? [] )
        }
    }
    func timeDurations() -> [Double] {
        return Roots.Root.map {
            (Double($0.sportTime ?? "") ?? 0.0) / 1000
        }
    }
}
