//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Use the timing parameter to control the speed of each dance move.
 
 A dance move can take various [beats](glossary://beat). Dancing with different beats makes dancing more changeable and rhythmic.
 
 You can use the `beats` parameter to set the duration of a dance move and create rhythms for the dance. If a dance move takes 2 beats, it would last twice as long as a dance move that takes 1 beat.
 
 For all dance move commands, the default value of `beats` is 1 if you leave it empty. You can enter an integer in `beats` to set the duration of your dance moves.
 
 - example: *Set duration of simple dance move*\
 `   moveLeftArm(60, beats:2)`
 
 1. Enter the number of beats in the basic dance move, simple dance move, and complex dance move.
 2. Tap **Run My Code** and see how MeeBot 2.0 responds to your code.
*/
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, moveToLeft(), moveToRight(), moveForward(), moveBackward(), raiseHands(), bend(), happy(), split(), skip(), twist(), stepAndShake(), crazyDance(), shake(), wave(), swagger(), moveToLeft(beats:), moveToRight(beats:), moveForward(beats:), moveBackward(beats:), raiseHands(beats:), bend(beats:), happy(beats:), split(beats:), skip(beats:), twist(beats:), stepAndShake(beats:), crazyDance(beats:), shake(beats:), wave(beats:), swagger(beats:), moveBody(moves:), moveBody(beats:moves:), moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:), moveLeftArm(angle:beats:), moveRightArm(angle:beats:), moveLeftLeg(angle:beats:), moveRightLeg(angle:beats:), moveLeftFoot(angle:beats:), moveRightFoot(angle:beats:))
moveRightArm(angle:/*#-editable-code*/30/*#-end-editable-code*/, beats:/*#-editable-code*/<#T##beats##Double#>/*#-end-editable-code*/)
moveLeftArm(angle:/*#-editable-code*/30/*#-end-editable-code*/, beats:/*#-editable-code*/<#T##beats##Double#>/*#-end-editable-code*/)
moveBody(beats:/*#-editable-code*/<#T##beats##UInt#>/*#-end-editable-code*/){
    //#-editable-code
    moveLeftFoot(angle:-30)
    moveLeftArm(angle:70)
    moveLeftLeg(angle:0)
    moveRightFoot(angle:30)
    moveRightArm(angle:-70)
    moveRightLeg(angle:0)
    //#-end-editable-code
}
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

