//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Use a for loop to repeat a sequence of dance moves.
 
 There are times when dances repeat sequences multiple times. This is when a [for loop](glossary://for%20loop) can help. A for loop is useful when you want to repeat a block of code a certain number of times.
 
 In this lesson, you will make MeeBot 2.0 perform a dance sequence that is repeated a certain number of times according to the intro music. You can program these dance moves using a for loop.
 
 1. Listen carefully to the looping music and determine how many times you want to repeat the moves.
 2. Tap the number placeholder and specify the number of repetitions.
 3. Enter the dance moves for each repetition.
 4. Tap **Run My Code** to see how MeeBot 2.0 responds to your code.
 */
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward(), raiseHands(), bend(), happy(), split(), skip(), twist(), stepAndShake(), crazyDance(), shake(), wave(), swagger(), moveToLeft(beats:), moveToRight(beats:), moveForward(beats:), moveBackward(beats:), raiseHands(beats:), bend(beats:), happy(beats:), split(beats:), skip(beats:), twist(beats:), stepAndShake(beats:), crazyDance(beats:), shake(beats:), wave(beats:), swagger(beats:), moveBody(beats:), moveBody(beats:moves:), moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:), moveLeftArm(angle:beats:), moveRightArm(angle:beats:), moveLeftLeg(angle:beats:), moveRightLeg(angle:beats:), moveLeftFoot(angle:beats:), moveRightFoot(angle:beats:))
for i in 1 ... /*#-editable-code*/<#T##numbers##Int#>/*#-end-editable-code*/ {
    //#-editable-code Tap to enter code
    
    //#-end-editable-code
}
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
