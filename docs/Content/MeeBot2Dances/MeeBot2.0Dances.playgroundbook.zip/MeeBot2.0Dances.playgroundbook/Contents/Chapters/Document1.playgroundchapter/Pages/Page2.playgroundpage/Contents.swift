//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Use Swift commands to tell MeeBot 2.0 to perform dance moves. Use at least 8 dance moves, 4 of which should be different.
 
 In this first lesson, you’ll need to write Swift [commands](glossary://command) to make MeeBot 2.0 dance, entering dance move commands in a sequence you like. Don’t forget that the dance moves you create should meet the goal.
  
 1. Tap to enter code. Basic dance move commands will appear in the shortcut bar.
 2. Select and enter the code with a [sequence](glossary://sequence) you like until you meet the goal. See how MeeBot 2.0 responds to your code.
 */
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward(), happy(), swing(), greeting(), cheer(), twist())
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code
