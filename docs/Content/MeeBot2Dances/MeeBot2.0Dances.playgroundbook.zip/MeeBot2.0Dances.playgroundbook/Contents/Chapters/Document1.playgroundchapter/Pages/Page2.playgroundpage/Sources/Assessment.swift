//
//  Assessment.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

let success = NSLocalizedString("### Well done.\nYou know how to use basic dance commands.\n\n[**Next Page**](@next)", comment:"Success message")

let number_tip = NSLocalizedString("Good, keep practicing. Use at least 8 dance moves. ", comment:"Number message")

let type_tip = NSLocalizedString("Nice, change just a little bit. Use at least 4 different dance moves.", comment:"Type message")
let empty_tip = NSLocalizedString("You need to enter basic move commands to make MeeBot 2.0 dance. Use at least 8 dance moves, 4 of which should be different.", comment:"Empty message")

public func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    let actions = commands.flatMap{$0.action == .start || $0.action == .finish ? nil : $0.action}

    if actions.count == 0 {
        return .fail(hints: [empty_tip], solution: nil)
    }
    if actions.count < 8 {
        return .fail(hints: [number_tip], solution: nil)
    }
    
    if Set(actions).count < 4 {
        return .fail(hints: [type_tip], solution: nil)
    }

    return .pass(message: success)
}
