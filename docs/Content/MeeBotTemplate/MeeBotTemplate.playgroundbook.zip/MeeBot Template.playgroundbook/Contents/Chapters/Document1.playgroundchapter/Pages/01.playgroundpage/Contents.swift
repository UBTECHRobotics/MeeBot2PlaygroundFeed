//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
*/
//#-end-hidden-code
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward(), raiseHands(), bend(), happy(), split(), skip(), twist(), stepAndShake(), bendAndTwist(), shake(), wave(), swagger(), crazyDance(), moveToLeft(beats:), moveToRight(beats:), moveForward(beats:), moveBackward(beats:), raiseHands(beats:), bend(beats:), happy(beats:), split(beats:), skip(beats:), twist(beats:), stepAndShake(beats:), bendAndTwist(beats:), shake(beats:), wave(beats:), swagger(beats:), moveBody(moves:), moveBody(beats:moves:), moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:), moveLeftArm(angle:beats:), moveRightArm(angle:beats:), moveLeftLeg(angle:beats:), moveRightLeg(angle:beats:), moveLeftFoot(angle:beats:), moveRightFoot(angle:beats:), crazyDance(beats:))
//#-code-completion(keyword, show, for, func, if, var, while)
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

