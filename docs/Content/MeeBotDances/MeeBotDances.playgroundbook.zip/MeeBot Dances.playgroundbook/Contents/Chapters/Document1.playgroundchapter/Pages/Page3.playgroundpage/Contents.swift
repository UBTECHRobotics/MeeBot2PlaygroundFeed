//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Learn how to control MeeBot’s [servo motors](glossary://servo%20motor).
 
 You can create more complex dance moves for MeeBot by controlling each of MeeBot's joints. MeeBot's joints are called servo motors.
 
 For a simple dance move that would move only one of MeeBot’s joints at a time, you can use a function like `moveLeftArm(60)`, which would rotate MeeBot’s left arm servo motor to 60 degrees. The number 60 inside the parentheses is called a [parameter](glossary://parameter).
 
 You can change the parameter, moving MeeBot’s servo motors at different angles. [Here’s](glossary://meebot%20servo%20angle%20limits) the range of MeeBot's servo motors.
 
 For a complex dance move that would move several joints at a time, use the function `moveBody(){}` and input the parts of MeeBot that you want to move into the function.
 
 1. Use a function like `moveLeftArm()`, and enter the value of the angle in parentheses to create a simple dance move.
 2. Use `moveBody(){}` and enter the simple dance move function to create a complex dance move.
 3. Tap **Run My Code** to see how MeeBot responds to your code.
 */
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
moveLeftArm(angle:/*#-editable-code Tap to enter code*/<#T##angle##Int#>/*#-end-editable-code*/)
moveBody {
    //#-code-completion(identifier, show, moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:))
    //#-editable-code Tap to enter code
    //#-end-editable-code
}
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

