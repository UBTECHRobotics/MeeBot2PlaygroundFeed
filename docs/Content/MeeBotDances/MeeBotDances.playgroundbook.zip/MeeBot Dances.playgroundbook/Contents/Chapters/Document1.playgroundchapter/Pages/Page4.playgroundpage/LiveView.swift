/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */

/// load the stage
let world = loadGridWorld(named: "Stage")

setUpLiveViewWith(world , .lesson4)
