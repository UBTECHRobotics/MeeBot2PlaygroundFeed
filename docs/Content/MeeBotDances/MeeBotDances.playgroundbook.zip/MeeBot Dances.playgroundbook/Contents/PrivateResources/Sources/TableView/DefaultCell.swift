//
//  DefaultCell.swift
//  LiveView
//
//  Created by Liz Chaddock on 6/29/17.
//  Copyright © 2017 Liz Chaddock. All rights reserved.
//

import Foundation
import UIKit
#if APP
    import DTModelStorage
#endif

class DefaultCell : UITableViewCell, ModelTransfer {
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .gray
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func update(with model: DefaultCellModel) {
        self.textLabel?.text = model.title
    }
}
