//#-hidden-code
//
//  Contents.swift
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal:** Unlock the doors to the lab by repeating the correct Morse Code sequence using AstroBot’s LED eyes.
 
 Great job! Now the ice must be brought inside the lab. To unlock the doors to the lab, AstroBot needs to enter a 3 digit door code to the computer using [Morse code](glossary://Morse%20code). For example, the Morse code for 1 is “[dot, dash, dash, dash, dash]”. To show that code using AstroBot’s [LED lights](glossary://LED%20lights), you will have these commands:
 
 ```showDot()```
 
 ```showDash()```
 
 This is the list of Morse code for the digits 0 to 9.
 
 0: dash, dash, dash, dash, dash
 
 1: dot, dash, dash, dash, dash
 
 2: dot, dot, dash, dash, dash
 
 3: dot, dot, dot, dash, dash
 
 4: dot, dot, dot, dot, dash
 
 5: dot, dot, dot, dot, dot
 
 6: dash, dot, dot, dot, dot
 
 7: dash, dash, dot, dot, dot
 
 8: dash, dash, dash, dot, dot
 
 9: dash, dash, dash, dash, dot
 
 
 1. Figure out how to send Morse Code with the “showDot” and “showDash” commands
 2. Send the 3 digit door code of 168 to the computer with the LED eyes

 */

//#-hidden-code
import PlaygroundSupport
let manager = ContentsManager.shared()
manager.page.needsIndefiniteExecution = true
let proxy = manager.page.liveView as? PlaygroundRemoteLiveViewProxy

proxy?.send(
    PlaygroundMessageToLiveView.didRunCode.playgroundValue
)

typealias Character = Actor
typealias Action = ActorAction

//TODO trigger animation to start here

//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, page, proxy, Listener, listener, planes, placedObjectsCount, planeCount, CharacterName, blu, hopper, expert, Character, let, plane, character, DetectionListener, sendAstrobotCommandToLiveView(command:), detectedPlane(plane:))
//#-code-completion(identifier, show, showDot(), showDash())
//#-code-completion(identifier, show, while, for, if, var, let, ., (, ), (),,)
manager.waitForPlane()
//#-end-hidden-code
//#-editable-code


//#-end-editable-code

//#-hidden-code
//
//showDot()
//showDash()
//showDash()
//showDash()
//showDash()
//
//
//
//showDash()
//showDot()
//showDot()
//showDot()
//showDot()
//
//
//
//showDash()
//showDash()
//showDash()
//showDot()
//showDot()
//
//#-end-hidden-code

//#-hidden-code

//openDoor()
//applaud()

proxy?.send(
    PlaygroundMessageToLiveView.finished.playgroundValue
)
//PlaygroundPage.current.finishExecution()
//#-end-hidden-code
