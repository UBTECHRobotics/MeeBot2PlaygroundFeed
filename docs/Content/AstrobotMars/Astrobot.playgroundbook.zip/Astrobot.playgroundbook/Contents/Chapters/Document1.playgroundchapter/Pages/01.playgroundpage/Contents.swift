//#-hidden-code
//
//  Contents.swift
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal:** Learn the basic commands for AstroBot
 
 In this first lesson, you will learn the basic commands for AstroBot. You will guide AstroBot to the rock near the front of the base and then instruct Astrobot to lift up the rock and put it down in the marked target area.
 
**Trivia** -  Did you know that the [gravity on Mars](glossary://Gravity%20on%20Mars) is only 38% of that on Earth?
 
 Tap to enter code. Command lists will appear in the shortcut bar.
 
 1. Select and enter the code with in the sequence that would navigate to the rock near our base.
 2. Lift up the rock and drop it off in the marked area.

 */

//#-hidden-code
import PlaygroundSupport
let manager = ContentsManager.shared()
manager.page.needsIndefiniteExecution = true
let proxy = manager.page.liveView as? PlaygroundRemoteLiveViewProxy

proxy?.send(
    PlaygroundMessageToLiveView.didRunCode.playgroundValue
)

typealias Character = Actor
typealias Action = ActorAction

//TODO trigger animation to start here

//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, page, proxy, Listener, listener, planes, placedObjectsCount, planeCount, CharacterName, blu, hopper, expert, Character, let, plane, character, DetectionListener, sendAstrobotCommandToLiveView(command:), detectedPlane(plane:))
//#-code-completion(identifier, show, moveForward(Distance:), turnRight(), turnLeft(), pickUp(), dropOff())
//#-code-completion(identifier, show, var, let, ., (, ), (),,)
manager.waitForPlane()
//#-end-hidden-code
//#-editable-code


//#-end-editable-code

//#-hidden-code
//turnLeft()
//moveForward(Distance:1)
//turnRight()
//moveForward(Distance:1)
//pickUp()
//dropOff()
//applaud()
//#-end-hidden-code

//#-hidden-code

proxy?.send(
    PlaygroundMessageToLiveView.finished.playgroundValue
)

//#-end-hidden-code
