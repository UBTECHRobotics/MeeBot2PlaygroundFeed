//
//  LiveView.swift
//
//  Copyright © 2016,2017 Apple Inc. All rights reserved.
//

import PlaygroundSupport
import UIKit

let page = PlaygroundPage.current
let liveViewController: LiveViewController = LiveViewController.makeFromStoryboard()
liveViewController.assessmentInfo = AssessmentInfo(evaluate: { return .fail(hints: ["Almost there... try again!"], solution: nil)})
liveViewController.lesson = 2
//liveViewController.isCommandListVisible = false
page.liveView = liveViewController
