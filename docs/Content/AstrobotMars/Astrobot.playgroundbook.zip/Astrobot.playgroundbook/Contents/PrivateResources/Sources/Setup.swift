import Foundation
import PlaygroundSupport

public class ContentsManager : NSObject {
    public var planeCount = 0
    var planes = [Plane]()
    let character = Character(name: CharacterName.astrobot)
    public let page = PlaygroundPage.current
    let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy
    let listener = DetectionListener()
    
    private static var sharedManager: ContentsManager = {
        let contentsManager = ContentsManager()
        contentsManager.playgroundPrologue()
        return contentsManager
    }()

    public class func shared() -> ContentsManager {
        return sharedManager
    }
    
    public func waitForPlane() {
        while (planeCount == 0) {
            RunLoop.main.run(mode: .defaultRunLoopMode, before: Date(timeIntervalSinceNow: 0.02))
        }
    }
    
    public func detectedPlane(plane: Plane) {
        if planeCount > 0 { return }
        var position = Point(x: 0, z: 0)
        
        plane.place(character:character, at:position)
        planeCount += 1
    }
    
    func playgroundPrologue() {
        var placedObjectsCount: Int { return planes.map{ $0.placedObjects.count }.reduce(0, +) }
        proxy?.delegate = listener
    }

}

// Listens for movement and triggers detectedMovement call
class DetectionListener: PlaygroundRemoteLiveViewProxyDelegate {
    func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy,
                             received message: PlaygroundValue) {

        guard let liveViewMessage = PlaygroundMessageFromLiveView(playgroundValue: message) else { return }
        let commandManager = ContentsManager.shared()

        switch liveViewMessage {
        case .planeFound(let plane):
            commandManager.planes.append(plane)
            commandManager.detectedPlane(plane: plane)

        case .objectPlacedOnPlane(let object, let plane, let position):
            if let index = commandManager.planes.index(of: plane) {
                object.position = position
                commandManager.planes[index].placedObjects.append(object)
                
                commandManager.proxy?.send(
                    PlaygroundMessageToLiveView.announceObjectPlacement(objects: commandManager.planes[index].placedObjects).playgroundValue
                )
            }
        case .passed(let message):
            PlaygroundPage.current.assessmentStatus = .pass(message: message)
            PlaygroundPage.current.finishExecution()

        case .failed(let message):
            PlaygroundPage.current.assessmentStatus = .fail(hints: [message], solution:nil)
            PlaygroundPage.current.finishExecution()
            
        case .completion():
            busyWithAction = false
            
        default:
            break
        }
    }
    func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) { }
}
