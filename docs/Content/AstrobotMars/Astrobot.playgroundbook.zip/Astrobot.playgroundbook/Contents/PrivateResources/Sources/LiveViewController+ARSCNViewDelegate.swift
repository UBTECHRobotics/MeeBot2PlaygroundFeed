//
//  LiveViewController+ARSCNViewDelegate.swift
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//

import ARKit

extension LiveViewController: ARSCNViewDelegate, ARSessionDelegate {
    
    // MARK: - ARSCNViewDelegate
    
    public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        DispatchQueue.main.async {
            if self.showingCameraVision {
                let hitTestViz = HitTestVisualization(sceneView: self.sceneView)
                hitTestViz.render()
            }
            
            self.updateFocusSquare()
            
            for object in self.virtualObjects {
                guard object.isModelLoaded else { continue }
                if let actor = object as? LiveActor {
                    actor.reactToRendering()
                }
            }
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
        if (parentPlaced == true) {return}
        self.parentPlaced = true
        updateQueue.async {
            
            let outOfBoundPosition = PositionAndOrientation(facing: .north, x: -1000, z: -1000)
            self.gameState.rockPositon = outOfBoundPosition
            self.gameState.iceCubePosition = outOfBoundPosition
            
            self.anchor = anchor
                
//            let parentNode = SCNNode()
            let center = planeAnchor.center
            let vector = SCNVector3.init(center)
            self.parentNode.transform = SCNMatrix4MakeTranslation(vector.x, vector.y, vector.z)
            if let n = SCNAssets.rootNode("Stage"){
                self.parentNode.addChildNode(n)
            }
            
            self.parentNode.addChildNode(self.actor.node)
            self.actor.startIdleLight()
            
            if self.lesson == 1 {
                if let n = SCNAssets.rootNode("stone"){
                    self.rock = n
                    self.parentNode.addChildNode(n)
                    n.localTranslate(by: SCNVector3Make(0, 0.2, 0))
                    self.rock.isHidden = true
                }
            }
            
            if self.lesson == 2 {
                if let n = SCNAssets.rootNode("large_rock"){
                    self.largeRock = n
                    self.parentNode.addChildNode(n)
                    self.largeRock.isHidden = true
                }
                
                if let n = SCNAssets.rootNode("obstacle_avoidance_destination"){
                    self.largeRockEnvironment = n
                    self.parentNode.addChildNode(n)
                    
                    self.largeRockEnvironment.isHidden = true
                }
            }
            
            if self.lesson == 3 {
                if let n = SCNAssets.rootNode("solar_panel"){
                    self.solar1 = n
                    self.solar2 = n.clone()
                    self.solar1.simdPosition = float3(0.114, 0, 0.117)
                    self.solar2.simdPosition = float3(-0.3, 0, 0.117)
                    self.parentNode.addChildNode(n)
                    self.parentNode.addChildNode(self.solar2)
                    
                    self.solar1.isHidden = true
                    self.solar2.isHidden = true
                }
            }
            
            if self.lesson == 4 {
                if let n = SCNAssets.rootNode("ice_cube"){
                    self.iceCube = n
                    self.parentNode.addChildNode(n)
                    self.iceCube.simdPosition = float3(0, 0, 0.2)
                    self.iceCube.isHidden = true
                }
                
                if let n = SCNAssets.rootNode("ice_cube_environment"){
                    self.iceCubeEnvironment = n
                    self.parentNode.addChildNode(n)
                    
                    self.iceCubeEnvironment.isHidden = true
                }
            }
            
//            if let n = SCNAssets.rootNode("closed_door"){
//                self.closedDoor = n
//                self.parentNode.addChildNode(n)
//
//                self.closedDoor.isHidden = true
//            }
//
//            if let n = SCNAssets.rootNode("opened_door"){
//                self.openedDoor = n
//                self.parentNode.addChildNode(n)
//
//                self.openedDoor.isHidden = true
//            }
            
            if self.lesson == 5 {
                if let n = SCNAssets.rootNode("lab_door"){
                    self.lab = n
                    self.parentNode.addChildNode(n)
                    
                    self.lab.isHidden = true
                    if let door = self.lab.childNode(withName: "Door_1", recursively: true){
                        self.labDoor = door
                    }
                }
            }

            if self.lesson == 5  || self.lesson == 6 {
                if let n = SCNAssets.rootNode("text_environment"){
                    self.actor.node.addChildNode(n)
                    
                    if let textNode = n.childNode(withName: "textNode", recursively: true){
                        self.textNode = textNode
                    }
                    
                    if let textNodeContainer = n.childNode(withName: "textNodeContainer", recursively: true){
                        self.textNodeContainer = textNodeContainer
                    }
                    
                    self.textNode.isHidden = true
                    
                    if let textGeometry = self.textNode.geometry as? SCNText {
                        self.textGeometry = textGeometry
                        self.textGeometry.string = ""
                    }
                }
            }
            
            if self.lesson == 1 {
                self.actor.node.simdPosition = float3(0, 0, -0.4)
                self.actor.node.simdEulerAngles = float3(0, 0, 0)
                self.gameState.robotPosition = PositionAndOrientation(facing: .south, x: 0, z: -2)
                self.rock.isHidden = false
                self.gameState.rockPositon = PositionAndOrientation(facing: .north, x: 1, z: 0)
            } else if self.lesson == 2 {
                self.actor.node.simdPosition = float3(-0.2, 0, -0.4)
                self.actor.node.simdEulerAngles = float3(0, .pi/2, 0)
                self.largeRock.isHidden = false
                self.largeRockEnvironment.isHidden = false
                self.gameState.robotPosition = PositionAndOrientation(facing: .east, x: -1, z: -2)
                self.gameState.boulderPositions = [PositionAndOrientation(facing: .east, x: 2, z: -2), PositionAndOrientation(facing: .east, x: 2, z: -1), PositionAndOrientation(facing: .east, x: 2, z: -3), PositionAndOrientation(facing: .east, x: 3, z: -2), PositionAndOrientation(facing: .east, x: 3, z: -1), PositionAndOrientation(facing: .east, x: 3, z: -3)]   // [(2, -2), (2, -1), (2, -3)]
                x = -1
                y = -2
                heading = 1
            } else if self.lesson == 3 {
                self.actor.node.simdPosition = float3(0, 0, -0.4)
                self.actor.node.simdEulerAngles = float3(0, 0, 0)
                self.gameState.robotPosition = PositionAndOrientation(facing: .south, x: 0, z: -2)
                self.solar1.isHidden = false
                self.solar2.isHidden = false
            } else if self.lesson == 4 {
                self.actor.node.simdPosition = float3(0, 0, -0.4)
                self.actor.node.simdEulerAngles = float3(0, 0, 0)
                self.gameState.robotPosition = PositionAndOrientation(facing: .south, x: 0, z: -2)
                self.iceCube.isHidden = false
                self.iceCubeEnvironment.isHidden = false
                self.gameState.iceCubePosition = PositionAndOrientation(facing: .south, x: 0, z: 1)
                self.gameState.iceCubeDestination = PositionAndOrientation(facing: .south, x: 0, z: -3)
                self.gameState.boulderPositions = [PositionAndOrientation(facing: .east, x: -1, z: -1), PositionAndOrientation(facing: .east, x: 0, z: -1), PositionAndOrientation(facing: .east, x: 1, z: -1)]
                
            } else if self.lesson == 5 {
                self.actor.node.simdPosition = float3(0, 0, 0.4)
                self.actor.node.simdEulerAngles = float3(0, 0, 0)
                self.actor.stopIdelLight()
                
                self.gameState.robotPosition = PositionAndOrientation(facing: .south, x: 0, z: 2)
                
                x = 0
                y = 2
                heading = 2
                
                self.lab.isHidden = false
                
                self.textNode.isHidden = false
                
            }   else if self.lesson == 6 {
                self.actor.node.simdPosition = float3(0, 0, -0.4)
                self.actor.node.simdEulerAngles = float3(0, 0, 0)
                self.gameState.robotPosition = PositionAndOrientation(facing: .south, x: 0, z: -2)
                self.actor.stopIdelLight()
                
                self.textNode.isHidden = false
            }
            else {
                
            }
            
            
            self.initialGameState = self.gameState
            self.initialTransform = self.actor.node.transform
            self.initialRockTransform = self.rock.transform
//            self.actor.setEyesColor(UIColor(0xcccccc))
            

            
            node.addChildNode(self.parentNode)
//            self.parentPlaced = true
            //DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {
            //    self.mainSequence()
            //})
            
            self.stopTracking()
        }
        
        DispatchQueue.main.async {
            self.statusViewController.cancelScheduledMessage(for: .planeEstimation)
            self.statusViewController.showMessage("SURFACE DETECTED")
            self.addPlane(node: node, anchor: planeAnchor)
            // Once we detect a surface, hide the focusSquare
            self.focusSquare.hide()
        }
        updateQueue.async {
            for object in self.virtualObjects {
                object.adjustOntoPlaneAnchor(planeAnchor, using: node)
            }
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
        // TODO: (Max) Figure out if this is really necessary
        if (planeAnchor == self.anchor) {
            updateQueue.async {
                self.parentNode.removeFromParentNode()
                node.addChildNode(self.parentNode)
            }
        }
        /*
        updateQueue.async {
            for object in self.virtualObjects {
                object.adjustOntoPlaneAnchor(planeAnchor, using: node)
            }
        }*/
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didRemove node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
        //self.removePlane(anchor: planeAnchor)
    }
    
    public func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        statusViewController.showTrackingQualityInfo(for: camera.trackingState, autoHide: true)
        
        switch camera.trackingState {
        case .notAvailable, .limited:
            statusViewController.escalateFeedback(for: camera.trackingState, inSeconds: 3.0)
            actor.stopIdelLight()
        case .normal:
            statusViewController.cancelScheduledMessage(for: .trackingStateEscalation)
        }
    }
    
    public func session(_ session: ARSession, didFailWithError error: Error) {
        guard error is ARError else { return }
        
        let errorWithInfo = error as NSError
        let messages = [
            errorWithInfo.localizedDescription,
            errorWithInfo.localizedFailureReason,
            errorWithInfo.localizedRecoverySuggestion
        ]
        
        // Use `flatMap(_:)` to remove optional error messages.
        let errorMessage = messages.flatMap({ $0 }).joined(separator: "\n")
        
        DispatchQueue.main.async {
            self.displayErrorMessage(title: "The AR session failed.", message: errorMessage)
        }
    }
    
}
