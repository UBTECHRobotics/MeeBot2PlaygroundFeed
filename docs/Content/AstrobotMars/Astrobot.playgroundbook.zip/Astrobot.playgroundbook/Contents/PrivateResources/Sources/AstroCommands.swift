public enum AstrobotCommand: String, Codable {
    case turnRight
    case turnLeft
    case moveForward
    case pickUp
    case dropOff
    case applaud
    case obstacleDetect
    case pickUpIceCube
    case dropOffIceCube
    case redEyeColor
    case blueEyeColor
    case greenEyeColor
    case dotEyeColor
    case barEyeColor
    case openDoor
    case shake
    case advanceHackCount
}
