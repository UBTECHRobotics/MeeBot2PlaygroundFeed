//
//  Actor.swift
//  ARKitImageRecognition
//
//  Created by WG on 2018/2/28.
//  Copyright © 2018年 Apple. All rights reserved.
//

import SceneKit

class AstroActor:NSObject{
    
    typealias Completion = (_ time : Double)  -> Void

    public let node = SCNNode()
    
    fileprivate let leftEyeLights: [SCNNode]//8 lights
    fileprivate let rightEyeLights: [SCNNode]//8 lights
    fileprivate var currentLedColors: [[String: Any]]?
    fileprivate var ledTimer:Timer?
    fileprivate var ledIdleTimer:Timer?
    fileprivate var ledIdleTimerOn = false
    fileprivate let defaultLedColor = UIColor(0x999999)
    
    fileprivate let leftTrack:SCNNode
    fileprivate let rightTrack:SCNNode
    fileprivate let leftTrackPoint:SCNNode
    fileprivate let rightTrackPoint:SCNNode
    fileprivate let leftWheels: [SCNNode]//3 wheels
    fileprivate let rightWheels: [SCNNode]//3 wheels
    
    fileprivate let shootOutBeam : SCNNode
    fileprivate var greenBeam : SCNNode = SCNNode()
    fileprivate var redBeam : SCNNode = SCNNode()
    
    fileprivate let iceCube:SCNNode
    
    public func shootIR(detected:Bool, completion: Completion? = nil) {
        shootOutBeam.scale = SCNVector3Make(1, 1, 0)
        shootOutBeam.isHidden = false
        
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 1
        SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn)
        shootOutBeam.scale = SCNVector3Make(1, 1, 1)
        SCNTransaction.completionBlock = {
            self.shootOutBeam.isHidden = true
            
            let resultBeam : SCNNode = detected ? self.redBeam : self.greenBeam
            resultBeam.isHidden = false
            resultBeam.opacity = 1.0
            
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 1
            SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn)
            resultBeam.opacity = 0.0
            SCNTransaction.completionBlock = {
                resultBeam.isHidden = true
                resultBeam.opacity = 1.0
                completion?(0)
            }
            SCNTransaction.commit()
        }
        SCNTransaction.commit()

        ledIdleTimer?.invalidate()
    }
    
    public func moveForward(_ completion: Completion? = nil) {
        move({
            node.transform = SCNMatrix4Mult(SCNMatrix4MakeTranslation(0, 0, 0.2), node.transform)
            moveLeftTrackAndWheels()
            moveRightTrackAndWheels()
        }, completion)
        moveForwardUpdate()
    }
    
    public func turnLeft(_ completion: Completion? = nil) {
        move( {
            node.transform = SCNMatrix4Mult(SCNMatrix4MakeRotation(.pi/2, 0, 1, 0), node.transform)
            moveLeftTrackAndWheels(false)
            moveRightTrackAndWheels()
        }, completion)
        turnLeftUpdate()
    }
    
    public func turnRight(_ completion: Completion? = nil){
        move({
            node.transform = SCNMatrix4Mult(SCNMatrix4MakeRotation(-.pi/2, 0, 1, 0), node.transform)
            moveLeftTrackAndWheels()
            moveRightTrackAndWheels(false)
        }, completion)
        turnRightUpdate()
    }
    
    
    override init() {
        var leftEyes = [SCNNode]()
        var rightEyes = [SCNNode]()
        var leftWheelsArray = [SCNNode]()
        var rightWheelsArray = [SCNNode]()
        if let n = SCNAssets.rootNode("astrobot"){
            node.addChildNode(n)
            for i in 1...8{
                if let l = node.childNode(withName: "Left_eye_\(i)", recursively: true){
                    leftEyes.append(l)
                    l.geometry?.firstMaterial?.diffuse.contents = defaultLedColor
//                    l.geometry?.firstMaterial?.multiply.contents = UIColor.white
                    l.geometry?.firstMaterial?.emission.contents = UIColor.black
                    l.geometry?.firstMaterial?.emission.intensity = 3000
                }
                if let l = node.childNode(withName: "Right_eye_\(i)", recursively: true){
                    rightEyes.append(l)
                    l.geometry?.firstMaterial?.diffuse.contents = defaultLedColor
//                    l.geometry?.firstMaterial?.multiply.contents = UIColor.white
                    l.geometry?.firstMaterial?.emission.contents = UIColor.black
                    l.geometry?.firstMaterial?.emission.intensity = 3000
                }
            }
            if let track = node.childNode(withName: "lvdai_2", recursively: true){
                leftTrack = track
                leftTrackPoint = SCNNode()
                leftTrackPoint.simdPosition = float3(5.23, 0, 0)
                node.childNodes.first?.addChildNode(leftTrackPoint)
            }else{
                leftTrack = node
                leftTrackPoint = node
            }
            if let track = node.childNode(withName: "lvdai_1", recursively: true){
                rightTrack = track
                rightTrackPoint = SCNNode()
                rightTrackPoint.simdPosition = float3(-5.23, 0, 0)
                node.childNodes.first?.addChildNode(rightTrackPoint)
            }else{
                rightTrack = node
                rightTrackPoint = node
            }
            for i in 1...3{
                if let wheel = node.childNode(withName: "left_gear_\(i)", recursively: true){
                    leftWheelsArray.append(wheel)
                }else{
                    leftWheelsArray.append(node)
                }
                if let wheel = node.childNode(withName: "right_gear_\(i)", recursively: true){
                    rightWheelsArray.append(wheel)
                }else{
                    rightWheelsArray.append(node)
                }
            }
            if let anIceCube = node.childNode(withName: "ice_cube", recursively: true){
                iceCube = anIceCube
            }else{
                iceCube = node
            }
        }else{
            for _ in 0..<8{
                leftEyes.append(node)
                rightEyes.append(node)
            }
            for _ in 0..<3{
                leftWheelsArray.append(node)
                rightWheelsArray.append(node)
            }
            leftTrack = node
            rightTrack = node
            leftTrackPoint = node
            rightTrackPoint = node
            iceCube = node
        }
        leftEyeLights = leftEyes
        rightEyeLights = rightEyes
        leftWheels = leftWheelsArray
        rightWheels = rightWheelsArray
        
        if let n = SCNAssets.rootNode("ir_beam_shoot_out"){
            shootOutBeam = n
            shootOutBeam.isHidden = true
            node.addChildNode(shootOutBeam)
        } else  {
            shootOutBeam = SCNNode()
        }
        
        if let n = SCNAssets.rootNode("green_beam"){
            greenBeam = n
            greenBeam.isHidden = true
            node.addChildNode(greenBeam)
        }
        
        if let n = SCNAssets.rootNode("red_beam"){
            redBeam = n
            redBeam.isHidden = true
            node.addChildNode(redBeam)
        }
    }

}

/*
 animations
 */
extension AstroActor{
    public func pickup(_ completion: Completion? = nil){
        ledIdleTimer?.invalidate()
        runAnimation("carryup"){
            DispatchQueue.main.async {
                self.ledIdleTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false){_ in
                    if self.ledIdleTimerOn{
                        self.showLights(.blink2)
                    }
                }
            }
            completion?(0)
        }

    }
    
    public func putdown(_ completion: Completion? = nil){
        ledIdleTimer?.invalidate()
        runAnimation("putdown"){
            DispatchQueue.main.async {
                self.ledIdleTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false){_ in
                    if self.ledIdleTimerOn{
                        self.showLights(.blink2)
                    }
                }
            }
            completion?(0)
        }
    }
    
    public func pickupIceCube(_ completion: Completion? = nil){
//        iceCube.simdPosition = float3(0, 0, 0.11)
        iceCube.isHidden = false
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7, execute: {
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.55
            SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
            self.iceCube.simdLocalTranslate(by: float3(0.0, 0.075, -0.025))
            SCNTransaction.commit()
        })

        pickup(completion)
    }
    
    public func putdownIceCube(_ completion: Completion? = nil){

        iceCube.isHidden = false
        
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 0.55
        SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        //        self.rock.transform = SCNMatrix4Mult(SCNMatrix4MakeTranslation(0, -1.5, 0), self.rock.transform)
        iceCube.simdLocalTranslate(by: float3(0.0, -0.075, 0.025))
        SCNTransaction.completionBlock = {
            self.iceCube.isHidden = true
        }
        //        iceCube.simdLocalTranslate(by: float3(0.03, 0, -0.075))
        SCNTransaction.commit()
        
        putdown(completion)
    }
    
    public func applaud(_ completion: Completion? = nil){
        ledIdleTimer?.invalidate()
        runAnimation("applaud"){completion?(0)}
        node.removeAllAudioPlayers()
        if let audio = SCNAssets.audioPlayer("happy.aac") {
            node.addAudioPlayer(audio)
        }

        showLights(.disco)
    }
    
    public func flashEyeColor(_ color:UIColor, completion: Completion? = nil) {
        setEyesColor(color)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
            self.setEyesColor(UIColor.black)
        })
        completion?(1.25)
    }
    
    public func flashBarEyeColor(_ color:UIColor, completion: Completion? = nil) {
        let colors:[UIColor] = [UIColor.black, UIColor.black, color, UIColor.black, UIColor.black, UIColor.black, color, UIColor.black]
        setEyesColors(colors)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
            self.setEyesColor(UIColor.black)
        })
        completion?(1.25)
    }
    
    public func runAnimation(_ scnName:String, completion:(()->Void)? = nil){
        let players = SCNAssets.animationPlayers(scnName)
        players.forEach{
            let an = $0.1
            an.animation.repeatCount = 1
            an.animation.isAppliedOnCompletion = true
            node.addAnimationPlayer(an, forKey: $0.0)
        }
        if let c = completion {
            players.values.first?.animation.animationDidStop = {_, _, _ in
                c()
            }
        }
    }
}

/*
 led lights
 */
extension AstroActor{
    public enum LightType: String{
        case blink1, blink2, scanning, happy, disco//, disco, dizzy, race, sad1, sad2, sad3, start, surprise, unnamed, wiper
    }
    
    public func showLights(_ type:LightType){
        if let path = Bundle.main.path(forResource: type.rawValue, ofType: "plist", inDirectory: "Lights"), let arr = NSArray(contentsOfFile: path) as? [[String: Any]]{
            currentLedColors = arr
            ledTimer?.invalidate()
            ledTick(0)
        }
    }
    
    public func setEyesColors(_ colors:[UIColor]){
        colors.enumerated().forEach{
            if $0.1 == UIColor.black {
                leftEyeLights[$0.0].geometry?.firstMaterial?.diffuse.contents = defaultLedColor
//                leftEyeLights[$0.0].geometry?.firstMaterial?.multiply.contents = UIColor.white
                rightEyeLights[$0.0].geometry?.firstMaterial?.diffuse.contents = defaultLedColor
//                rightEyeLights[$0.0].geometry?.firstMaterial?.multiply.contents = UIColor.white
            }else{
                leftEyeLights[$0.0].geometry?.firstMaterial?.diffuse.contents = $0.1
//                leftEyeLights[$0.0].geometry?.firstMaterial?.multiply.contents = "Scenes.scnassets/Textures/led_multi_light.jpg"
                rightEyeLights[$0.0].geometry?.firstMaterial?.diffuse.contents = $0.1
//                rightEyeLights[$0.0].geometry?.firstMaterial?.multiply.contents = "Scenes.scnassets/Textures/led_multi_light.jpg"
            }
        }
    }
    
    public func setEyesColor(_ color:UIColor){
        var newColor = color
        if color == UIColor.black {
            newColor = defaultLedColor
        }
        leftEyeLights.forEach{
            $0.geometry?.firstMaterial?.diffuse.contents = newColor
        }
        rightEyeLights.forEach{
            $0.geometry?.firstMaterial?.diffuse.contents = newColor
        }
    }
    
    public func startIdleLight(){
        ledIdleTimerOn = true
        DispatchQueue.main.async {
            self.ledIdleTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false){_ in
                if self.ledIdleTimerOn{
                    self.showLights(.blink2)
                }
            }
        }
    }
    
    public func stopIdelLight(){
        ledIdleTimerOn = false
        ledIdleTimer?.invalidate()
    }
}

/*
 private functions
 */
extension AstroActor{
    fileprivate func ledTick(_ idx:Int) {
        ledIdleTimer?.invalidate()
        guard currentLedColors?.count ?? 0 > idx, let item = currentLedColors?[idx], let duration = item["duration"] as? Int, let colors = item["rgb"] as? [Int] else {
            currentLedColors = nil
            
            DispatchQueue.main.async {
                self.ledIdleTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false){_ in
                    if self.ledIdleTimerOn{
                        self.showLights(.blink2)
                    }
                }
            }
            return
        }
        ledTimer = Timer.scheduledTimer(withTimeInterval: TimeInterval(duration)/1000, repeats: false){_ in
            self.setEyesColors(colors.map{(UIColor($0))})
            self.ledTick(idx + 1)
        }
    }
    fileprivate func move(_ block:()->Void, _ completion: Completion?){
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 1
        SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        block()
        SCNTransaction.completionBlock = {
            self.node.removeAllAudioPlayers()
            DispatchQueue.main.async {
                self.ledIdleTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false){_ in
                    if self.ledIdleTimerOn{
                        self.showLights(.blink2)
                    }
                }
            }
            completion?(0)
        }
        SCNTransaction.commit()
        
        ledIdleTimer?.invalidate()
        node.removeAllAudioPlayers()
        if let audio = SCNAssets.audioPlayer("cart_boost.mp3") {
            node.addAudioPlayer(audio)
        }
        
//        if let _ = SCNAssets.particle("footprint"){
//        }
    }
    fileprivate func moveLeftTrackAndWheels(_ forward: Bool = true){
        let trans1 = leftTrack.geometry?.firstMaterial?.diffuse.contentsTransform ?? SCNMatrix4()
        leftTrack.geometry?.firstMaterial?.diffuse.contentsTransform = SCNMatrix4Mult(SCNMatrix4MakeTranslation(0, forward ? 1 : -1, 0), trans1)
        let trans2 = leftTrack.geometry?.firstMaterial?.transparent.contentsTransform ?? SCNMatrix4()
        leftTrack.geometry?.firstMaterial?.transparent.contentsTransform = SCNMatrix4Mult(SCNMatrix4MakeTranslation(0, forward ? 1 : -1, 0), trans2)
        
        leftWheels.forEach{
            $0.eulerAngles.x = $0.eulerAngles.x + .pi * (forward ? 2 : -2)
        }
        
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        leftTrackPoint.removeAllParticleSystems()
        if let p = SCNAssets.particle("dust") {
            leftTrackPoint.addParticleSystem(p)
        }
        leftTrackPoint.eulerAngles.y = forward ? 0 : .pi
        SCNTransaction.commit()
    }
    fileprivate func moveRightTrackAndWheels(_ forward: Bool = true){
        let trans1 = rightTrack.geometry?.firstMaterial?.diffuse.contentsTransform ?? SCNMatrix4()
        rightTrack.geometry?.firstMaterial?.diffuse.contentsTransform = SCNMatrix4Mult(SCNMatrix4MakeTranslation(0, forward ? 1 : -1, 0), trans1)
        let trans2 = rightTrack.geometry?.firstMaterial?.transparent.contentsTransform ?? SCNMatrix4()
        rightTrack.geometry?.firstMaterial?.transparent.contentsTransform = SCNMatrix4Mult(SCNMatrix4MakeTranslation(0, forward ? 1 : -1, 0), trans2)
        
        rightWheels.forEach{
            $0.eulerAngles.x = $0.eulerAngles.x + .pi * (forward ? 2 : -2)
        }
        
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        rightTrackPoint.removeAllParticleSystems()
        if let p = SCNAssets.particle("dust") {
            rightTrackPoint.addParticleSystem(p)
        }
        rightTrackPoint.eulerAngles.y = forward ? 0 : .pi
        SCNTransaction.commit()
    }
}
