//
//  Assessment.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

let success = NSLocalizedString("### Well done!\nYou knew how to dance with music.\n\n[**Next Page**](@next)", comment:"Success message")

let tip = NSLocalizedString("Enter the number of times in for loop so MeeBot can repeat the dance sequence throughout the Intro music.", comment:"Tip message")

public func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    return commands.count > 2 ? .pass(message: success) : .fail(hints: [tip], solution: nil)
}
