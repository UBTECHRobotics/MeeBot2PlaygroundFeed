//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
//#-hidden-code
import SceneKit
import PlaygroundSupport
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Connect and see a dance performed by the real MeeBot.
 
 MeeBot is a programmable dancing robot.
  
 In this playground, you will learn how to connect MeeBot and how MeeBot responds to code.
 
 1. Turn on Bluetooth on your device and power up MeeBot.
 2. Tap the **bluetooth** button in the upper-right corner of Live View.
 3. Check MeeBot's [device ID](glossary://device%20ID) and select the corresponding MeeBot on the device list.
 4. Tap **Run My Code** after MeeBot is successfully connected and the real MeeBot will show you a short preview dance [sequence](glossary://sequence).
 */
//#-hidden-code
func dance() {
    wave()
    bend()
    for _ in 0..<2 {
        twist()
    }
    stepAndShake()
    bendAndTwist()
    split()
    for _ in 0..<2 {
        skip()
    }
    shake()
    swagger()
    shake()
    for _ in 0..<3 {
        wave()
    }
}
//#-end-hidden-code
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, dance())
//#-editable-code
dance()
//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

