//
//  Assessment.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

let success = NSLocalizedString("### Well done!\nGood dancing.\n\n[**Next Page**](@next)", comment:"Success message")

let if_tip = NSLocalizedString("Don't forget to dance while the music is playing. Put your dance routine under the if statement.", comment:"Type message")

let else_tip = NSLocalizedString("Good! You’re taking your dancing to the next level. Put a new dance routine under the else statement. ", comment:"Type message")

public func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    let checker = ContentsChecker(contents: PlaygroundPage.current.text)
    guard let state_if = checker.conditionalNodes.first, state_if.body.count > 0 else {
        return .fail(hints: [if_tip], solution: nil)
    }
    guard let state_else = checker.conditionalNodes.last, state_else.body.count > 0 else {
        return .fail(hints: [else_tip], solution: nil)
    }
    return .pass(message: success)
}
